package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

	@GetMapping("/hash")
	public ResponseEntity<Map<String, String>> hash(
			@RequestParam(name = "data", defaultValue = "Artemis Financial secure communications sample") String data) {
		Map<String, String> response = new LinkedHashMap<>();
		response.put("timestamp", Instant.now().toString());
		response.put("algorithm", "SHA-256");
		response.put("data", data);

		try {
			response.put("checksum", sha256Hex(data));
			return ResponseEntity.ok(response);
		} catch (NoSuchAlgorithmException exception) {
			response.put("error", "Unable to generate checksum");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	private String sha256Hex(String input) throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
		StringBuilder hexString = new StringBuilder(hashBytes.length * 2);

		for (byte hashByte : hashBytes) {
			hexString.append(String.format("%02x", hashByte));
		}

		return hexString.toString();
	}
}