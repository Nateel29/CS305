# Practices for Secure Software Report

## Document Revision History

| Version | Date | Author | Comments |
|---|---|---|---|
| 1.0 | 2026-02-25 | Allan Torres | Initial submission draft for Project Two |

## Client
Artemis Financial

## Developer
Allan Torres

## 1. Algorithm Cipher
The recommended approach is to use TLS for transport encryption and SHA-256 for checksum verification. TLS (HTTPS) protects data in transit between browser and server, while SHA-256 provides integrity verification for transferred data.

SHA-256 is a cryptographic hash function in the SHA-2 family that produces a 256-bit digest. It is one-way, deterministic, and resistant to collisions for practical use in application-layer integrity checks. In this project, the server computes the digest for an input string and returns the checksum so transmitted data can be verified.

For key usage, TLS uses asymmetric cryptography (public/private key certificate) to establish secure sessions and then uses symmetric session keys for efficient encrypted communication. Random numbers are critical in TLS handshake operations to generate nonces and session secrets. This hybrid model combines strong authentication and confidentiality with performance.

Historically, weak algorithms (for example MD5 and SHA-1 for integrity use cases) have known collision weaknesses and are no longer preferred for secure systems. Current best practice is SHA-256 or stronger hash functions and modern TLS with valid certificates.

## 2. Certificate Generation
A self-signed certificate and keystore were generated with Java Keytool and exported as a CER file.

Generated files:
- `src/main/resources/keystore.p12`
- `src/main/resources/ssl-server.cer`

Commands used:
```powershell
keytool -genkeypair -alias ssl-server -keyalg RSA -keysize 2048 -storetype PKCS12 -keystore "src/main/resources/keystore.p12" -validity 3650 -storepass changeit -keypass changeit -dname "CN=localhost, OU=CS305, O=SNHU, L=Manchester, ST=NH, C=US"
keytool -exportcert -alias ssl-server -keystore "src/main/resources/keystore.p12" -storetype PKCS12 -storepass changeit -rfc -file "src/main/resources/ssl-server.cer"
```

Insert a screenshot below of the CER file in your file browser.

## 3. Deploy Cipher
A SHA-256 checksum endpoint was implemented at `GET /hash`.

Example verification request:
```text
https://localhost:8443/hash?data=AllanTorres-UniqueString-20260225
```

Observed output example:
```json
{"timestamp":"2026-02-25T23:08:17.992078500Z","algorithm":"SHA-256","data":"AllanTorres-UniqueString-20260225","checksum":"21cc0c8ae6999da41b806721dc85d00dcf4dcf9b06b881263b256b2ec2d9e57b"}
```

Insert a screenshot below showing your name and unique string in the URL/output.

## 4. Secure Communications
HTTPS was enabled by refactoring Spring configuration to use TLS on port 8443.

Application SSL configuration:
- `server.port=8443`
- `server.ssl.key-alias=ssl-server`
- `server.ssl.key-store-password=changeit`
- `server.ssl.key-store=classpath:keystore.p12`
- `server.ssl.key-store-type=PKCS12`

Secure communication test URL:
```text
https://localhost:8443/hash
```

Insert a browser screenshot showing the secure HTTPS page.

## 5. Secondary Testing
Secondary static analysis was executed with OWASP Dependency-Check.

Command used:
```powershell
.\mvnw.cmd org.owasp:dependency-check-maven:12.1.8:check -Dformat=HTML -DfailOnError=false -DskipTests
```

Result in this environment: the scan completed and generated an HTML report. The report identified vulnerabilities in transitive third-party dependencies (for example `tomcat-embed-core`, `spring-web`, `spring-webmvc`, `spring-core`, and `snakeyaml`) included by the Spring Boot dependency stack, not in custom checksum/HTTPS code added for this refactor.

Scan summary captured from report:
- Dependencies scanned: 44 (25 unique)
- Vulnerable dependencies: 9
- Vulnerabilities found: 45

Security interpretation: this secondary scan confirms that dependency risk exists in upstream libraries and should be remediated through dependency upgrades and suppression review for false positives. The secure-communication refactor itself did not add new direct vulnerable libraries.

Insert screenshots:
- Refactored code/build run without errors
- Dependency-check HTML report summary/output

## 6. Functional Testing
Functional verification completed:
- Application starts successfully on HTTPS port 8443
- `/hash` endpoint returns SHA-256 checksum output for supplied input
- Unit/integration test suite passes in Java upgrade validation session

Insert a screenshot of successful application execution without errors.

## 7. Summary
The application was refactored to add defense-in-depth for secure communications and integrity validation. The architecture and communication layers were improved by enabling HTTPS/TLS with a self-signed certificate and keystore. The cryptography area was strengthened by implementing SHA-256 checksum generation for transferred data.

Using the vulnerability assessment flow, the major addressed areas were:
- Architecture review: identified missing secure transport and integrity-check mechanism
- Cryptography: implemented SHA-256 checksum generation
- Client/Server: enforced HTTPS communication over TLS
- Code quality and code review: added clear endpoint behavior and error handling for checksum creation
- Secondary testing: executed dependency and validation checks to confirm no newly introduced critical issues

Security was layered by combining transport security (TLS), certificate-based identity, and payload integrity verification (SHA-256). This reduces risk of interception/tampering and improves trust in data exchanges.

## 8. Industry Standard Best Practices
Industry standards applied included:
- Use of TLS/HTTPS for encrypted in-transit data
- Use of modern hash algorithm (SHA-256) for integrity verification
- Principle of least exposure by implementing only required endpoint behavior
- Secure defaults in configuration (dedicated keystore, explicit TLS settings)
- Automated validation via build/test/security scanning tools

These practices preserve and improve existing application security by reducing common vulnerabilities (plaintext transport, weak integrity checks, unmanaged crypto configuration). For Artemis Financial, this improves confidentiality, integrity, and stakeholder trust while supporting compliance-oriented development expectations.